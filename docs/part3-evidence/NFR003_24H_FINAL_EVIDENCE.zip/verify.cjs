'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const assert = require('node:assert/strict');

const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const read = (dir, name) => fs.readFileSync(path.join(dir, name));
const json = (dir, name) => JSON.parse(read(dir, name));
const exists = (dir, name) => fs.existsSync(path.join(dir, name));
const near = (actual, expected) => {
  assert.ok(Number.isFinite(actual) && Math.abs(actual - expected) < 0.001, 'Inconsistent monotonic measurement');
};

function timestamp(value) {
  const ms = Date.parse(value);
  assert.ok(Number.isFinite(ms) && new Date(ms).toISOString() === value, 'Invalid UTC timestamp');
  return ms;
}

function lines(bytes) {
  const text = bytes.toString('utf8');
  if (!text) return [];
  assert.ok(text.endsWith('\n'), 'Truncated journal');
  return text.slice(0, -1).split('\n').map(line => JSON.parse(line));
}

function isTeamInitiated(record) {
  if (!['evaluation_authority', 'faculty_approval_status', 'faculty_acceptance_status'].some(key => Object.hasOwn(record, key))) return false;
  assert.equal(record.evaluation_authority, 'TEAM_INITIATED');
  assert.equal(record.faculty_approval_status, 'NOT_OBTAINED');
  assert.equal(record.faculty_acceptance_status, 'PENDING');
  assert.equal(record.faculty_approval_reference, null);
  assert.equal(record.mode, '24H_ACCEPTANCE');
  assert.equal(record.schema_version, 3);
  return true;
}

function verifyMeasurement(dir) {
  if (!exists(dir, 'summary.json')) {
    assert.ok(exists(dir, 'interruption.json'), 'Run is unsealed or still active');
    const stop = json(dir, 'interruption.json');
    assert.equal(stop.status, 'FAIL_INTERRUPTED_NO_SUMMARY');
    const end = json(dir, 'end-state.json');
    assert.ok(end.monitor === null || end.monitor.status === 'exited' || end.monitor.status === 'dead');
    const files = ['probes.jsonl', 'clock.jsonl'].filter(name => exists(dir, name));
    const run = json(dir, 'run.json');
    const expected = run.mode === '24H_ACCEPTANCE' ? 2880 : 20;
    const raw = files.includes('probes.jsonl') ? read(dir, 'probes.jsonl').toString('utf8') : '';
    const completeLines = raw.split('\n').slice(0, -1);
    assert.ok(completeLines.length <= expected);
    for (const [i, line] of completeLines.entries()) assert.equal(JSON.parse(line).index, i + 1);
    return {
      status: stop.status, canonical_summary: false, retained_journals: files,
      expected, durable_probe_rows: completeLines.length, missing_tail: expected - completeLines.length,
      probe_journal_has_partial_line: Boolean(raw && !raw.endsWith('\n')),
    };
  }

  assert.ok(!exists(dir, 'interruption.json'), 'Conflicting outcomes');
  const s = json(dir, 'summary.json');
  assert.ok([2, 3].includes(s.schema_version));
  assert.equal(s.test, 'TC-AVL-01');
  assert.equal(typeof s.interrupted, 'boolean');
  assert.ok(['SMOKE_NOT_ACCEPTANCE', '24H_ACCEPTANCE'].includes(s.mode));
  const smoke = s.mode === 'SMOKE_NOT_ACCEPTANCE';
  const url = new URL(s.target);
  assert.ok(!url.username && !url.password && !url.search && !url.hash && url.pathname === '/api/v1/health');
  assert.ok(smoke ? ['http:', 'https:'].includes(url.protocol) : url.protocol === 'https:');
  const team = isTeamInitiated(s);
  if (smoke || team) assert.equal(s.faculty_approval_reference, null);
  else assert.match(s.faculty_approval_reference, /^[\w .@:/#-]{3,160}$/);
  const count = smoke ? s.expected_probes : 2880;
  const interval = smoke ? Math.round(s.interval_seconds * 1000) : 30000;
  assert.ok(Number.isSafeInteger(count) && count >= 1 && count <= (smoke ? 20 : 2880));
  assert.ok(Number.isSafeInteger(interval) && interval >= 50 && interval <= 30000);
  assert.equal(s.expected_probes, count);
  assert.equal(s.interval_seconds, interval / 1000);
  const start = timestamp(s.scheduled_start_utc);
  const end = start + count * interval;
  assert.equal(timestamp(s.scheduled_end_utc), end);

  const clockBytes = read(dir, 'clock.jsonl');
  const probeBytes = read(dir, 'probes.jsonl');
  assert.equal(s.clock_sha256, hash(clockBytes));
  assert.equal(s.evidence_sha256, hash(probeBytes));
  const clock = lines(clockBytes);
  assert.ok(clock.length >= 2);
  const first = clock[0];
  const last = clock.at(-1);
  let previous = first;
  let anomaly = false;
  const samples = new Map();
  for (const { utc_ms: utc, monotonic_ms: mono } of clock) {
    assert.ok(Number.isSafeInteger(utc) && Number.isFinite(mono) && mono >= previous.monotonic_ms);
    const step = utc - previous.utc_ms - (mono - previous.monotonic_ms);
    const drift = utc - first.utc_ms - (mono - first.monotonic_ms);
    anomaly ||= Math.abs(step) > 1000 || Math.abs(drift) > 1000 || mono - previous.monotonic_ms > 10000;
    if (!samples.has(mono)) samples.set(mono, new Set());
    samples.get(mono).add(utc);
    previous = { utc_ms: utc, monotonic_ms: mono };
  }
  assert.equal(s.clock_anomaly, anomaly);
  const monoStart = first.monotonic_ms + (start - first.utc_ms);
  const monoEnd = monoStart + count * interval;
  near(s.monotonic_start_ms, monoStart);
  near(s.monotonic_end_deadline_ms, monoEnd);
  near(s.monotonic_end_ms, last.monotonic_ms);
  near(s.monotonic_elapsed_ms, last.monotonic_ms - monoStart);
  assert.equal(timestamp(s.recorded_end_utc), last.utc_ms);
  assert.equal(s.utc_elapsed_ms, last.utc_ms - start);
  const rows = lines(probeBytes);
  assert.ok(rows.length <= count);
  if (!s.interrupted) assert.equal(rows.length, count);
  let healthy = 0;
  let late = 0;
  let missed = 0;
  let priorFinish = -Infinity;
  for (const [i, row] of rows.entries()) {
    assert.equal(row.index, i + 1);
    assert.equal(timestamp(row.scheduled_at_utc), start + i * interval);
    const utc = timestamp(row.observed_at_utc);
    const finish = timestamp(row.finished_at_utc);
    assert.ok(samples.get(row.observed_monotonic_ms)?.has(utc));
    assert.ok(samples.get(row.finished_monotonic_ms)?.has(finish));
    assert.ok(row.finished_monotonic_ms >= row.observed_monotonic_ms && row.observed_monotonic_ms >= priorFinish);
    priorFinish = row.finished_monotonic_ms;
    const lateness = row.observed_monotonic_ms - (monoStart + i * interval);
    near(row.lateness_ms, lateness);
    assert.ok(lateness >= 0, 'Probe before monotonic slot');
    late += Number(lateness > 1000);
    const skip = lateness > Math.max(500, Math.min(5000, interval / 2)) || utc >= end || utc < start;
    if (s.schema_version === 3) {
      assert.equal(row.dispatched_at_utc, skip ? null : row.observed_at_utc, 'Invalid dispatch UTC');
      assert.equal(row.dispatch_monotonic_ms, skip ? null : row.observed_monotonic_ms, 'Invalid dispatch monotonic time');
      if (skip) {
        assert.equal(row.finished_monotonic_ms, row.observed_monotonic_ms);
        assert.equal(row.finished_at_utc, row.observed_at_utc);
      } else {
        const elapsed = row.finished_monotonic_ms - row.dispatch_monotonic_ms;
        near(row.latency_ms, elapsed);
        if (row.reason === 'TIMEOUT') assert.ok(elapsed >= 5000, 'Timeout before deadline');
        else assert.ok(elapsed <= 5000 && row.latency_ms <= 5000, 'Response exceeded deadline');
      }
    }
    if (skip) {
      missed++;
      assert.equal(row.reason, 'MISSED_SCHEDULED_SLOT');
      assert.equal(row.latency_ms, null);
      assert.equal(row.status, null);
    } else {
      assert.ok(Number.isFinite(row.latency_ms) && row.latency_ms >= 0);
      if (row.status !== null) assert.ok(Number.isSafeInteger(row.status) && row.status >= 100 && row.status <= 599);
    }
    let success = false;
    if (row.checks !== null) {
      assert.equal(row.status, 200);
      assert.ok(!skip && (s.schema_version === 2 || row.latency_ms <= 5000));
      const { status_ok, process_up, database_connected } = row.checks;
      assert.ok([status_ok, process_up, database_connected].every(value => typeof value === 'boolean'));
      success = status_ok && process_up && database_connected;
      assert.equal(row.reason, success ? 'HEALTHY' : 'UNHEALTHY_BODY');
    } else if (!skip) {
      if (row.status === null) assert.ok(['TIMEOUT', 'NETWORK_OR_TLS_ERROR'].includes(row.reason));
      else if (row.status === 200) assert.ok(['INVALID_JSON', 'OVERSIZE_BODY', 'INCOMPLETE_BODY'].includes(row.reason));
      else assert.equal(row.reason, 'HTTP_' + row.status);
    }
    assert.equal(row.ok, success);
    healthy += Number(success);
  }
  const missing = count - rows.length;
  const minimum = smoke ? null : Math.ceil(count * 99 / 100);
  const dualDeadline = last.utc_ms >= end && last.monotonic_ms >= monoEnd;
  const complete = dualDeadline && !s.interrupted && !anomaly && !missing;
  const pass = complete && healthy >= (smoke ? count : minimum);
  const status = smoke ? (pass ? 'SMOKE_PASS_NOT_ACCEPTANCE' : 'SMOKE_FAIL') : (pass ? 'PASS' : 'FAIL');
  const availability = Number((healthy * 100 / count).toFixed(4));
  assert.deepEqual(
    [s.actual_first_slot_utc, s.healthy, s.observed_probes, s.failed, s.missing_probes, s.late_slots, s.missed_slots,
      s.min_successes_for_99_percent, s.availability_percent, s.complete_window, s.status],
    [rows[0]?.observed_at_utc ?? null, healthy, rows.length, rows.length - healthy, missing, late, missed,
      minimum, availability, !smoke && complete, status],
  );
  if (exists(dir, 'run.json')) {
    const run = json(dir, 'run.json');
    const source = read(dir, 'source.json').toString('utf8').trim();
    assert.equal(hash(source), run.source_sha256, 'Source manifest digest differs');
    assert.equal(s.mode, run.mode);
    if (exists(dir, 'end-state.json')) {
      const state = json(dir, 'end-state.json');
      assert.ok(state.monitor && state.monitor.status === 'exited', 'Completed summary needs an exited monitor');
      assert.equal(state.monitor.restart_count, 0, 'Monitor restarted');
      assert.equal(state.monitor.image_manifest, run.monitor_image_manifest, 'Monitor image differs');
      assert.equal(state.monitor.exit_code, ['PASS', 'SMOKE_PASS_NOT_ACCEPTANCE'].includes(status) ? 0 : 1);
    }
    assert.equal(s.target, run.target);
    if (!smoke) {
      assert.equal(s.scheduled_start_utc, new Date(run.start_utc).toISOString());
      assert.equal(s.faculty_approval_reference, run.faculty_approval_reference);
    }
  }
  return { status, canonical_summary: true, healthy, expected: count, missing, missed, late, availability, dual_deadline: dualDeadline, clock_anomaly: anomaly };
}

const provenanceNames = [
  'run.json', 'environment.json', 'source.json', 'start-state.json', 'launch-intent.json',
  'prepared-container.json', 'start-request.json', 'launch.json', 'end-state.json',
];

function ledger(dir, name, required, exact = false) {
  const actual = new Set();
  for (const line of read(dir, name).toString('utf8').trimEnd().split(/\r?\n/)) {
    const match = /^([0-9a-f]{64}) {2}([a-zA-Z0-9][a-zA-Z0-9_.-]*)$/.exec(line);
    assert.ok(match && match[2] !== name && !actual.has(match[2]), 'Invalid manifest entry');
    const [, digest, member] = match;
    assert.ok(fs.lstatSync(path.join(dir, member)).isFile(), 'Manifest entry must be a regular file');
    assert.equal(hash(read(dir, member)), digest, 'Digest mismatch for ' + member);
    actual.add(member);
  }
  for (const member of required) assert.ok(actual.has(member), 'Missing ledger entry: ' + member);
  if (exact) assert.equal(actual.size, required.length);
  return actual.size;
}

function provenance(dir, s) {
  const required = s ? ['probes.jsonl', 'clock.jsonl', 'summary.json']
    : ['interruption.json', ...['probes.jsonl', 'clock.jsonl'].filter(name => exists(dir, name))];
  for (const name of [...provenanceNames, ...required, 'RUN_SHA256SUMS']) {
    assert.ok(exists(dir, name), 'Missing mandatory provenance: ' + name);
  }
  ledger(dir, 'RUN_SHA256SUMS', [...provenanceNames, ...required], true);
  const [run, env, source, before, intent, prepared, request, launch, after] =
    provenanceNames.map(name => json(dir, name));
  const sha = /^[0-9a-f]{64}$/;
  const manifest = /^sha256:[0-9a-f]{64}$/;
  const instant = value => {
    assert.ok(typeof value === 'string' && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,9})?Z$/.test(value));
    const ms = Date.parse(value);
    assert.ok(Number.isFinite(ms), 'Invalid Docker or host timestamp');
    return ms;
  };
  assert.equal(run.schema_version, 3);
  assert.ok(['SMOKE_NOT_ACCEPTANCE', '24H_ACCEPTANCE'].includes(run.mode));
  const smoke = run.mode === 'SMOKE_NOT_ACCEPTANCE';
  const team = isTeamInitiated(run);
  assert.match(run.run_id, /^[a-z0-9][a-z0-9-]{2,45}$/);
  assert.equal(run.container_name, 'se-nfr003-' + run.run_id);
  assert.equal(run.target, 'https://web/api/v1/health');
  assert.equal(run.expected_probes, smoke ? 20 : 2880);
  assert.equal(run.interval_ms, smoke ? 10000 : 30000);
  assert.match(run.source_sha256, sha);
  assert.match(run.ca_sha256, sha);
  assert.match(run.leaf_sha256, sha);
  assert.match(run.monitor_image_manifest, manifest);
  assert.equal(run.source_sha256, hash(read(dir, 'source.json').toString('utf8').trim()));
  assert.match(source.revision, /^[0-9a-f]{40}$/);
  assert.match(source.archive_sha256, sha);
  assert.ok(Object.keys(source.files).length > 0 && Object.values(source.files).every(digest => sha.test(digest)));
  for (const name of ['scripts/nfr003/monitor.cjs', 'scripts/nfr003/verify.cjs', 'scripts/nfr003/operations.ps1', 'compose.nfr003.yaml']) {
    assert.match(source.files[name], sha);
  }
  assert.equal(run.windows_power_original_manifest, 'environment.json');
  assert.match(run.docker_engine, /linux/i);
  const envTime = instant(env.captured_at_utc);
  if (!smoke) {
    assert.equal(env.ac_power, 'Online');
    assert.equal(env.ac_sleep_seconds, 0);
    assert.equal(env.ac_hibernate_seconds, 0);
    assert.equal(env.updates.windows_update_reboot_required, false);
    assert.equal(env.updates.servicing_reboot_pending, false);
    assert.match(env.windows_time, /^Leap Indicator:\s*0/im);
    assert.ok(env.ac_lid_close_action === 0 || run.keep_lid_open === true);
    if (!team) assert.match(run.faculty_approval_reference, /^[\w .@:/#-]{3,160}$/);
    assert.match(run.preflight_smoke_id, /^[a-z0-9][a-z0-9-]{2,45}$/);
    assert.equal(instant(run.scheduled_end_utc) - instant(run.start_utc), 86400000);
  } else {
    assert.equal(run.faculty_approval_reference, null);
    assert.equal(run.start_utc, null);
    assert.equal(run.scheduled_end_utc, null);
  }
  assert.equal(intent.run_id, run.run_id);
  assert.equal(intent.mode, run.mode);
  assert.match(intent.token, /^[0-9a-f]{32}$/);
  for (const name of provenanceNames.slice(0, 4)) {
    assert.equal(intent.metadata_sha256[name], hash(read(dir, name)), 'Launch-intent hash mismatch for ' + name);
  }
  const command = ['--url', run.target, '--output-dir', '/evidence'];
  if (smoke) command.push('--smoke', '--count', '20', '--interval-ms', '10000');
  else {
    if (team) command.push('--team-initiated');
    else command.push('--approval-ref', run.faculty_approval_reference);
    command.push('--start-at', run.start_utc);
  }
  assert.deepEqual(intent.command, command);
  assert.equal(before.monitor, null);
  for (const service of ['mongo', 'api', 'web']) {
    assert.match(before[service].id, sha);
    assert.match(before[service].image_manifest, manifest);
    assert.equal(before[service].image_manifest, run.application_images[service]);
    assert.equal(before[service].status, 'running');
    assert.ok(instant(before[service].started_at) <= instant(before.captured_at_utc));
  }
  assert.match(prepared.container_id, sha);
  assert.match(prepared.image_id, manifest);
  assert.equal(prepared.image_manifest, run.monitor_image_manifest);
  assert.equal(prepared.token, intent.token);
  assert.equal(request.container_id, prepared.container_id);
  assert.equal(request.token, intent.token);
  assert.equal(launch.container_id, prepared.container_id);
  assert.equal(launch.token, intent.token);
  assert.equal(launch.image_id, prepared.image_id);
  assert.equal(launch.image_manifest, run.monitor_image_manifest);
  assert.equal(launch.name, run.container_name);
  assert.deepEqual(launch.command, command);
  const final = after.monitor;
  assert.equal(final.id, launch.container_id);
  assert.equal(final.image_id, launch.image_id);
  assert.equal(final.image_manifest, launch.image_manifest);
  assert.equal(final.launch_token, intent.token);
  assert.deepEqual(final.command, command);
  assert.equal(final.started_at, launch.started_at);
  assert.equal(final.restart_policy, 'no');
  assert.equal(final.restart_count, 0);
  assert.ok(['exited', 'dead'].includes(final.status));
  assert.ok(Number.isInteger(final.exit_code));
  const started = instant(launch.started_at);
  const finished = instant(final.finished_at);
  assert.ok(envTime <= instant(before.captured_at_utc) && instant(before.captured_at_utc) <= instant(intent.prepared_at_utc));
  assert.ok(instant(intent.prepared_at_utc) <= instant(prepared.captured_at_utc));
  assert.ok(instant(prepared.captured_at_utc) <= instant(request.requested_at_utc));
  // Host and guest timestamps are captured on different clocks. Allow a small
  // tolerance for comparisons across those clock domains.
  assert.ok(instant(request.requested_at_utc) <= started + 1000);
  assert.ok(started <= instant(launch.captured_at_utc) + 1000 && started <= finished);
  assert.ok(finished <= instant(after.captured_at_utc) + 1000);
  if (!smoke) assert.ok(started <= instant(run.start_utc), 'Monitor started after official window');
  if (!s) return run;
  assert.equal(s.mode, run.mode);
  assert.equal(isTeamInitiated(s), team, 'Summary and run authority differ');
  assert.equal(s.target, run.target);
  assert.equal(s.faculty_approval_reference, run.faculty_approval_reference);
  assert.equal(s.expected_probes, run.expected_probes);
  assert.equal(s.interval_seconds * 1000, run.interval_ms);
  if (!smoke) {
    assert.equal(s.scheduled_start_utc, run.start_utc);
    assert.equal(s.scheduled_end_utc, run.scheduled_end_utc);
  }
  assert.ok(started <= instant(s.recorded_end_utc) && instant(s.recorded_end_utc) <= finished + 1000);
  assert.equal(final.status, 'exited');
  assert.equal(final.oom_killed, false);
  assert.equal(final.exit_code, ['PASS', 'SMOKE_PASS_NOT_ACCEPTANCE'].includes(s.status) ? 0 : 1);
  return run;
}

function verifyRun(dir) {
  const s = exists(dir, 'summary.json') ? json(dir, 'summary.json') : null;
  const run = exists(dir, 'run.json') ? json(dir, 'run.json') : null;
  if (s?.schema_version === 3 || run?.schema_version === 3) {
    provenance(dir, s);
    if (s) assert.equal(s.schema_version, 3);
  } else {
    assert.ok(s?.mode !== '24H_ACCEPTANCE' && run?.mode !== '24H_ACCEPTANCE',
      'Official evidence requires schema 3 and complete provenance');
  }
  const result = verifyMeasurement(dir);
  return run?.evaluation_authority === 'TEAM_INITIATED'
    ? {
      ...result, evaluation_authority: run.evaluation_authority,
      faculty_approval_status: run.faculty_approval_status, faculty_acceptance_status: run.faculty_acceptance_status,
    }
    : result;
}


function verifyPackage(dir) {
  const names = fs.readdirSync(dir).filter(name => name !== 'SHA256SUMS');
  ledger(dir, 'SHA256SUMS', names, true);
  const result = verifyRun(dir);
  assert.deepEqual(json(dir, 'verification.json'), result);
  return { ...result, verified_package_files: names.length };
}

module.exports = { verifyRun, verifyPackage, verifyMeasurement };
if (require.main === module) {
  try {
    const [dir, mode] = process.argv.slice(2);
    if (!dir || (mode && mode !== '--package')) throw new Error('Usage: node verify.cjs DIRECTORY [--package]');
    console.log(JSON.stringify(mode ? verifyPackage(dir) : verifyRun(dir), null, 2));
  } catch (error) {
    console.error('VERIFY ERROR: ' + error.message);
    process.exitCode = 1;
  }
}
