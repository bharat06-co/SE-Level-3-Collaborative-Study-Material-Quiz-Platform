# NFR-003 run nfr003-team-20261107-202610-d6d05b

Outcome **FAIL**.
Team-initiated evaluation. Faculty approval was not obtained. Faculty acceptance remains pending.
2880/2880 healthy, 100% availability, 0 skipped slots and 0 missing tail slots.
Same-host deployment. Container observations are taken before launch and after exit.
